﻿NCAudio Release T-1.2 version
Please read the following :
(1) Tested on Windows 7 32-bit as well as Windows 10 (64-bit)
(2) Will need Admin privileges to run
(3) Changes the Pitch without changing the tempo
(4) Run NCAudio.exe directly
(5) Will require .NET 3.5 minimum
(6) This version is free but restricted to 60 plays
(7) For the Pro version contact napta58@gmail.com
(8) You can save the changes made as a .wav file
(9) Volume control add

